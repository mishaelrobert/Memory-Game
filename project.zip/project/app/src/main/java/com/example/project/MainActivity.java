package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class    MainActivity extends AppCompatActivity {
    public static final String Bundle_Msg = "com.example.myapplication.extra.Bundle_Msg";
    private static final String TAG = MainActivity.class.getSimpleName();
    private EditText i_user;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        i_user = findViewById(R.id.i_name);

    }

    public void SendToSecond(View view) {
        Log.d(TAG, "Clicked button");
        Intent intent = new Intent(this, SecondActivity.class);
        String Message = i_user.getText().toString();
        if (Message.equals("")) {
            Toast.makeText(MainActivity.this, "please insert name", Toast.LENGTH_SHORT).show();
        } else {
            intent.putExtra(Bundle_Msg, Message);
            startActivity(intent);
        }
    }
}