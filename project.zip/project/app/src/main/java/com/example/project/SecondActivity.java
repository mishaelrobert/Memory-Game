package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class SecondActivity extends AppCompatActivity {

    Random r;
    TextView current_lv, display_num;
    EditText i_num;
    Button btn_try;
    String random_num;
    int lv = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        current_lv = findViewById(R.id.user_lv);
        display_num = findViewById(R.id.display_number);
        i_num = findViewById(R.id.enter_num);
        btn_try = findViewById(R.id.btn_try);
        current_lv.setText("level:" + lv);
        Intent incomigIntent = getIntent();
        String msg_from_main = incomigIntent.getStringExtra(MainActivity.Bundle_Msg);
        TextView nick = findViewById(R.id.nickname);
        nick.setText("Nickname:" + msg_from_main);
        r = new Random();
        random_num=generate_num(lv);
        display_num.setText(random_num);
        btn_try.setVisibility(View.GONE);
        i_num.setVisibility(View.GONE);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                btn_try.setVisibility(View.VISIBLE);
                i_num.setVisibility(View.VISIBLE);
                display_num.setVisibility(View.GONE);
            }
            },1000);
        btn_try.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(random_num.equals(i_num.getText().toString()))
                {
                    btn_try.setVisibility(View.GONE);
                    i_num.setVisibility(View.GONE);
                    display_num.setVisibility(View.VISIBLE);
                    lv++;
                    current_lv.setText("level:" + lv);
                    random_num=generate_num(lv);
                    display_num.setText(random_num);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            btn_try.setVisibility(View.VISIBLE);
                            i_num.setVisibility(View.VISIBLE);
                            display_num.setVisibility(View.GONE);
                        }
                    }, 1000);



                }
                    else
                {
                    display_num.setVisibility(View.VISIBLE);
                    display_num.setText("Game over, You've reached level:"+lv);
                    btn_try.setVisibility(View.GONE);
                    i_num.setVisibility(View.GONE);
                }
            }
        });
    }


    private String generate_num(int lv)
    {
        String new_num="";
        for(int i=0;i<lv;i++)
        {
            int digit=r.nextInt(10);
            new_num=new_num+""+digit;
        }
        return new_num;


    }
}